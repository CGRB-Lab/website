##
## Old Sashimi plot interface
##
def main():
    print "plot.py interface to Sashimi plot is now deprecated. " \
          "Please run \'sashimi_plot\' instead."

if __name__ == "__main__":
    main()
