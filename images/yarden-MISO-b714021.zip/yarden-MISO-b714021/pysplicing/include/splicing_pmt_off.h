/* -*- mode: C -*-  */

#ifdef ATOMIC
#undef ATOMIC
#endif

#ifdef ATOMIC_IO
#undef ATOMIC_IO
#endif

#ifdef BASE
#undef BASE
#endif

#ifdef BASE_EPSILON
#undef BASE_EPSILON
#endif

#ifdef CONCAT2
#undef CONCAT2
#endif

#ifdef CONCAT2x
#undef CONCAT2x
#endif

#ifdef CONCAT3
#undef CONCAT3
#endif

#ifdef CONCAT3x
#undef CONCAT3x
#endif

#ifdef CONCAT4
#undef CONCAT4
#endif

#ifdef CONCAT4x
#undef CONCAT4x
#endif

#ifdef FP
#undef FP
#endif

#ifdef FUNCTION
#undef FUNCTION
#endif

#ifdef IN_FORMAT
#undef IN_FORMAT
#endif

#ifdef MULTIPLICITY
#undef MULTIPLICITY
#endif

#ifdef ONE
#undef ONE
#endif

#ifdef OUT_FORMAT
#undef OUT_FORMAT
#endif

#ifdef SHORT
#undef SHORT
#endif

#ifdef TYPE
#undef TYPE
#endif

#ifdef ZERO
#undef ZERO
#endif

#ifdef HEAPMORE
#undef HEAPMORE
#endif

#ifdef HEAPLESS
#undef HEAPLESS
#endif

#ifdef HEAPMOREEQ
#undef HEAPMOREEQ
#endif

#ifdef HEAPLESSEQ
#undef HEAPLESSEQ
#endif

#ifdef SUM
#undef SUM
#endif

#ifdef PROD
#undef PROD
#endif

#ifdef NOTORDERED
#undef NOTORDERED
#endif

#ifdef EQ
#undef EQ
#endif

#ifdef DIFF
#undef DIFF
#endif

#ifdef DIV
#undef DIV
#endif
