
#include "splicing.h"

#include <string.h>

