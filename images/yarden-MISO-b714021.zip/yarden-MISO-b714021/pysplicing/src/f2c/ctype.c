#define My_ctype_DEF
#include "fctype.h"
